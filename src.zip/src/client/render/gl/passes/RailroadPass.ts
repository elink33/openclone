/**
 * RailroadPass — GPU railroad overlay rendering.
 *
 * Renders railroad tracks as a fullscreen quad pass, reading rail orientation
 * from an R8UI texture. Two LOD modes: detailed 3×3 sub-grid sprites at high
 * zoom, screen-space anti-aliased lines at medium zoom. Hidden below minimum
 * zoom threshold.
 *
 * Also renders ghost railroad paths (semi-transparent) for build-mode preview.
 *
 * Data flow:
 *   Uint8Array railroadState → R8UI texture (rail type per tile, 0=none, 1-6=type)
 *   GhostPreviewData         → R8UI ghost texture (ghost rail paths)
 *   R8UI terrainTex           → water detection for bridge rendering (shader neighbor lookup)
 *   R16UI tileTex (shared)   → owner lookup for rail color
 *   RGBA32F paletteTex        → player color lookup
 *   RGBA32F effectTex (shared) → per-owner railroad cosmetic effect
 */

import type { GhostPreviewData, TerrainRect } from "../../types";
import type { RenderSettings } from "../RenderSettings";
import overlayVertSrc from "../shaders/map-overlay/overlay.vert.glsl?raw";
import railroadFragSrc from "../shaders/railroad/railroad.frag.glsl?raw";
import {
  getPaletteSize,
  MAX_TRAIL_COLORS,
  RAILROAD_EFFECT_BLOCK,
} from "../utils/ColorUtils";
import {
  createMapQuad,
  createProgram,
  createTexture2D,
  shaderSrc,
} from "../utils/GlUtils";
import { TILE_DEFINES } from "../utils/TileCodec";

// ---------------------------------------------------------------------------
// Rail orientation (0-5) → texture value (1-6, 0=none)
// ---------------------------------------------------------------------------

const VERTICAL = 0;
const HORIZONTAL = 1;
const TOP_LEFT = 2;
const TOP_RIGHT = 3;
const BOTTOM_LEFT = 4;
const BOTTOM_RIGHT = 5;

function railExtremity(tile: number, next: number, w: number): number {
  const dx = (next % w) - (tile % w);
  const dy = (next - (next % w)) / w - (tile - (tile % w)) / w;
  if (dx === 0) return VERTICAL;
  if (dy === 0) return HORIZONTAL;
  return VERTICAL;
}

function railDirection(
  prev: number,
  cur: number,
  next: number,
  w: number,
): number {
  const x1 = prev % w,
    y1 = (prev - x1) / w;
  const x2 = cur % w,
    y2 = (cur - x2) / w;
  const x3 = next % w,
    y3 = (next - x3) / w;
  const dx1 = x2 - x1,
    dy1 = y2 - y1;
  const dx2 = x3 - x2,
    dy2 = y3 - y2;
  if (dx1 === dx2 && dy1 === dy2) {
    return dx1 !== 0 ? HORIZONTAL : VERTICAL;
  }
  if ((dx1 === 0 && dx2 !== 0) || (dx1 !== 0 && dx2 === 0)) {
    if (dx1 === 0 && dx2 === 1 && dy1 === -1) return BOTTOM_RIGHT;
    if (dx1 === 0 && dx2 === -1 && dy1 === -1) return BOTTOM_LEFT;
    if (dx1 === 0 && dx2 === 1 && dy1 === 1) return TOP_RIGHT;
    if (dx1 === 0 && dx2 === -1 && dy1 === 1) return TOP_LEFT;
    if (dx1 === 1 && dx2 === 0 && dy2 === -1) return TOP_LEFT;
    if (dx1 === -1 && dx2 === 0 && dy2 === -1) return TOP_RIGHT;
    if (dx1 === 1 && dx2 === 0 && dy2 === 1) return BOTTOM_LEFT;
    if (dx1 === -1 && dx2 === 0 && dy2 === 1) return BOTTOM_RIGHT;
  }
  return VERTICAL;
}

// ---------------------------------------------------------------------------
// RailroadPass
// ---------------------------------------------------------------------------

export class RailroadPass {
  private program: WebGLProgram;
  private railroadTex: WebGLTexture;
  private ghostRailTex: WebGLTexture;
  private tileTex: WebGLTexture;
  private paletteTex: WebGLTexture;
  private effectTex: WebGLTexture;
  private terrainTex: WebGLTexture;
  private vao: WebGLVertexArrayObject;

  private uCamera: WebGLUniformLocation;
  private uMapSize: WebGLUniformLocation;
  private uZoom: WebGLUniformLocation;
  private uTime: WebGLUniformLocation;
  private uRailDetailZoom: WebGLUniformLocation;
  private uRailAlpha: WebGLUniformLocation;
  private uRailFade: WebGLUniformLocation;
  private uRailThickness: WebGLUniformLocation;
  private uGhostOwnerID: WebGLUniformLocation;
  private uLocalPlayerID: WebGLUniformLocation;
  private uLocalRailColor: WebGLUniformLocation;
  private uHoverOwner: WebGLUniformLocation;

  private mapW: number;
  private mapH: number;
  private settings: RenderSettings;

  /**
   * Reference to the caller-owned railroad state (RailroadCache's array;
   * stable identity, mutated in place). The pass keeps no copy — the array
   * must stay current until the flush. Null until the first upload.
   */
  private liveRailroadRef: Uint8Array | null = null;
  private railroadDirty = false;

  /**
   * Current ghost overlay content, sparse: tile ref → texel value (1-6 =
   * orientation, 7 = overlap highlight). Ghost paths cover at most a few
   * thousand tiles, so tracking them beats a full-map array + full-map
   * texture upload per preview change.
   */
  private ghostTiles = new Map<number, number>();
  /** Pending ghost texel writes, interleaved [ref, value, …]. */
  private ghostOps: number[] = [];
  private ghostOwnerID = 0;

  private localPlayerID = 0;
  private localRailColor: [number, number, number] = [0.75, 0.75, 0.75];
  /** Hovered territory's owner (0 = none) — shows that player's railroad effect. */
  private hoverOwner = 0;

  /** Wall-clock start, for uTime (seconds) — matches TrailPass so the
   *  railroad effect animates at the same pace as the trail effects. */
  private readonly startTime = performance.now();

  constructor(
    private gl: WebGL2RenderingContext,
    mapW: number,
    mapH: number,
    tileTex: WebGLTexture,
    paletteTex: WebGLTexture,
    effectTex: WebGLTexture,
    terrainBytes: Uint8Array,
    settings: RenderSettings,
  ) {
    this.mapW = mapW;
    this.mapH = mapH;
    this.tileTex = tileTex;
    this.paletteTex = paletteTex;
    this.effectTex = effectTex;
    this.settings = settings;

    this.program = createProgram(
      gl,
      overlayVertSrc,
      shaderSrc(railroadFragSrc, {
        PALETTE_SIZE: getPaletteSize(),
        RAILROAD_EFFECT_ROW_BASE: RAILROAD_EFFECT_BLOCK * MAX_TRAIL_COLORS,
        ...TILE_DEFINES,
      }),
    );

    this.uCamera = gl.getUniformLocation(this.program, "uCamera")!;
    this.uMapSize = gl.getUniformLocation(this.program, "uMapSize")!;
    this.uZoom = gl.getUniformLocation(this.program, "uZoom")!;
    this.uTime = gl.getUniformLocation(this.program, "uTime")!;
    this.uRailDetailZoom = gl.getUniformLocation(
      this.program,
      "uRailDetailZoom",
    )!;
    this.uRailAlpha = gl.getUniformLocation(this.program, "uRailAlpha")!;
    this.uRailFade = gl.getUniformLocation(this.program, "uRailFade")!;
    this.uRailThickness = gl.getUniformLocation(
      this.program,
      "uRailThickness",
    )!;
    this.uGhostOwnerID = gl.getUniformLocation(this.program, "uGhostOwnerID")!;
    this.uLocalPlayerID = gl.getUniformLocation(
      this.program,
      "uLocalPlayerID",
    )!;
    this.uLocalRailColor = gl.getUniformLocation(
      this.program,
      "uLocalRailColor",
    )!;
    this.uHoverOwner = gl.getUniformLocation(this.program, "uHoverOwner")!;

    // Texture unit bindings + ghost defaults
    gl.useProgram(this.program);
    gl.uniform1i(gl.getUniformLocation(this.program, "uRailroadTex"), 0);
    gl.uniform1i(gl.getUniformLocation(this.program, "uTileTex"), 1);
    gl.uniform1i(gl.getUniformLocation(this.program, "uPalette"), 2);
    gl.uniform1i(gl.getUniformLocation(this.program, "uTerrainTex"), 3);
    gl.uniform1i(gl.getUniformLocation(this.program, "uGhostRailTex"), 4);
    gl.uniform1i(gl.getUniformLocation(this.program, "uEffect"), 5);
    gl.uniform1f(this.uGhostOwnerID, 0);

    // R8UI terrain texture (static, uploaded once for bridge detection)
    this.terrainTex = createTexture2D(gl, {
      width: mapW,
      height: mapH,
      internalFormat: gl.R8UI,
      format: gl.RED_INTEGER,
      type: gl.UNSIGNED_BYTE,
      data: terrainBytes,
      filter: gl.NEAREST,
    });

    // R8UI railroad texture (null data = zero-initialized per the WebGL spec)
    this.railroadTex = createTexture2D(gl, {
      width: mapW,
      height: mapH,
      internalFormat: gl.R8UI,
      format: gl.RED_INTEGER,
      type: gl.UNSIGNED_BYTE,
      data: null,
      filter: gl.NEAREST,
    });

    // R8UI ghost railroad texture (same format, ghost paths only)
    this.ghostRailTex = createTexture2D(gl, {
      width: mapW,
      height: mapH,
      internalFormat: gl.R8UI,
      format: gl.RED_INTEGER,
      type: gl.UNSIGNED_BYTE,
      data: null,
      filter: gl.NEAREST,
    });

    this.vao = createMapQuad(gl, mapW, mapH);
  }

  uploadRailroadState(railroadState: Uint8Array): void {
    this.liveRailroadRef = railroadState;
    this.railroadDirty = true;
  }

  setLocalPlayer(smallID: number): void {
    this.localPlayerID = smallID;
  }

  /** Rail color for the local player (0–1 RGB). */
  setLocalRailColor(r: number, g: number, b: number): void {
    this.localRailColor = [r, g, b];
  }

  /** Hovered territory's owner (0 = none) — shows that player's railroad effect. */
  setHighlightOwner(ownerID: number): void {
    this.hoverOwner = ownerID;
  }

  /**
   * Sub-upload terrain bytes for regions that changed (water-nuke
   * conversions). Keeps the R8UI water-detection texture in sync with the
   * simulation. Each rect's bytes are stored row-major, concatenated in
   * `bytes` in rect order; one texSubImage2D per rect.
   */
  applyTerrainRects(rects: readonly TerrainRect[], bytes: Uint8Array): void {
    if (rects.length === 0) return;
    const gl = this.gl;
    gl.bindTexture(gl.TEXTURE_2D, this.terrainTex);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    let offset = 0;
    for (const r of rects) {
      gl.texSubImage2D(
        gl.TEXTURE_2D,
        0,
        r.x,
        r.y,
        r.w,
        r.h,
        gl.RED_INTEGER,
        gl.UNSIGNED_BYTE,
        bytes,
        offset,
      );
      offset += r.w * r.h;
    }
  }

  updateGhostPreview(data: GhostPreviewData | null): void {
    const next = new Map<number, number>();

    if (data) {
      const maxRef = this.mapW * this.mapH;

      // Ghost rail paths (1-6 = orientation)
      for (const path of data.ghostRailPaths) {
        if (path.length === 0) continue;
        const tiles = this.computePathOrientations(path);
        for (const t of tiles) {
          if (t.ref >= 0 && t.ref < maxRef) {
            next.set(t.ref, t.type + 1);
          }
        }
      }

      // Overlapping railroad highlights (7 = green highlight marker)
      // overlappingRailroads contains resolved tile refs (not rail IDs)
      for (const ref of data.overlappingRailroads) {
        if (ref >= 0 && ref < maxRef) {
          next.set(ref, 7);
        }
      }

      this.ghostOwnerID = data.ownerID;
    } else {
      this.ghostOwnerID = 0;
    }

    // Queue texel writes for the diff: clear tiles that left the ghost,
    // (re)write tiles whose value is new or changed.
    for (const ref of this.ghostTiles.keys()) {
      if (!next.has(ref)) this.ghostOps.push(ref, 0);
    }
    for (const [ref, value] of next) {
      if (this.ghostTiles.get(ref) !== value) this.ghostOps.push(ref, value);
    }
    this.ghostTiles = next;
  }

  /** Draw the railroad overlay. Must be called with alpha blending enabled. */
  draw(cameraMatrix: Float32Array, zoom: number): void {
    const gl = this.gl;
    const rs = this.settings.railroad;

    // Flush queued ghost texel writes even when faded out, so the op queue
    // can't grow unboundedly while the player previews at low zoom.
    this.flushGhostOps();

    // Fade out as zoom drops below railMinZoom; fully invisible at railMinZoom - railFadeRange
    const fadeRange = Math.max(rs.railFadeRange, 0);
    const fadeStart = rs.railMinZoom - fadeRange;
    const fade =
      fadeRange <= 0
        ? zoom >= rs.railMinZoom
          ? 1
          : 0
        : Math.min(1, Math.max(0, (zoom - fadeStart) / fadeRange));
    if (fade <= 0) return;

    // Flush railroad state → GPU
    if (this.railroadDirty && this.liveRailroadRef !== null) {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.railroadTex);
      gl.texSubImage2D(
        gl.TEXTURE_2D,
        0,
        0,
        0,
        this.mapW,
        this.mapH,
        gl.RED_INTEGER,
        gl.UNSIGNED_BYTE,
        this.liveRailroadRef,
      );
      this.railroadDirty = false;
    }

    gl.useProgram(this.program);
    gl.uniformMatrix3fv(this.uCamera, false, cameraMatrix);
    gl.uniform2f(this.uMapSize, this.mapW, this.mapH);
    gl.uniform1f(this.uZoom, zoom);
    gl.uniform1f(this.uTime, (performance.now() - this.startTime) / 1000);
    gl.uniform1f(this.uRailDetailZoom, rs.railDetailZoom);
    gl.uniform1f(this.uRailAlpha, rs.railAlpha);
    gl.uniform1f(this.uRailFade, fade);
    gl.uniform1f(this.uRailThickness, rs.railThickness);
    gl.uniform1f(this.uGhostOwnerID, this.ghostOwnerID);
    gl.uniform1f(this.uLocalPlayerID, this.localPlayerID);
    gl.uniform1f(this.uHoverOwner, this.hoverOwner);
    gl.uniform3f(
      this.uLocalRailColor,
      this.localRailColor[0],
      this.localRailColor[1],
      this.localRailColor[2],
    );

    // Bind textures: 0=railroad, 1=tile, 2=palette, 3=terrain, 4=ghostRail,
    // 5=effect
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.railroadTex);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, this.tileTex);

    gl.activeTexture(gl.TEXTURE2);
    gl.bindTexture(gl.TEXTURE_2D, this.paletteTex);

    gl.activeTexture(gl.TEXTURE3);
    gl.bindTexture(gl.TEXTURE_2D, this.terrainTex);

    gl.activeTexture(gl.TEXTURE4);
    gl.bindTexture(gl.TEXTURE_2D, this.ghostRailTex);

    gl.activeTexture(gl.TEXTURE5);
    gl.bindTexture(gl.TEXTURE_2D, this.effectTex);

    gl.bindVertexArray(this.vao);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }

  /**
   * Apply queued ghost texel writes to the ghost texture, one texel per
   * texSubImage2D. Ghost diffs are path-sized (at most a few thousand
   * texels), far cheaper than the full-map upload a dense mirror needs.
   */
  private flushGhostOps(): void {
    const ops = this.ghostOps;
    if (ops.length === 0) return;
    const gl = this.gl;
    gl.activeTexture(gl.TEXTURE4);
    gl.bindTexture(gl.TEXTURE_2D, this.ghostRailTex);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    const scratch = new Uint8Array(1);
    for (let i = 0; i < ops.length; i += 2) {
      const ref = ops[i];
      const x = ref % this.mapW;
      const y = (ref - x) / this.mapW;
      scratch[0] = ops[i + 1];
      gl.texSubImage2D(
        gl.TEXTURE_2D,
        0,
        x,
        y,
        1,
        1,
        gl.RED_INTEGER,
        gl.UNSIGNED_BYTE,
        scratch,
      );
    }
    ops.length = 0;
  }

  // ---- Rail orientation computation ----

  private computePathOrientations(
    tileRefs: number[],
  ): Array<{ ref: number; type: number }> {
    if (tileRefs.length === 0) return [];
    if (tileRefs.length === 1) return [{ ref: tileRefs[0], type: VERTICAL }];
    const w = this.mapW;
    const result: Array<{ ref: number; type: number }> = [];
    result.push({
      ref: tileRefs[0],
      type: railExtremity(tileRefs[0], tileRefs[1], w),
    });
    for (let i = 1; i < tileRefs.length - 1; i++) {
      result.push({
        ref: tileRefs[i],
        type: railDirection(tileRefs[i - 1], tileRefs[i], tileRefs[i + 1], w),
      });
    }
    const last = tileRefs.length - 1;
    result.push({
      ref: tileRefs[last],
      type: railExtremity(tileRefs[last], tileRefs[last - 1], w),
    });
    return result;
  }

  dispose(): void {
    const gl = this.gl;
    gl.deleteProgram(this.program);
    gl.deleteTexture(this.railroadTex);
    gl.deleteTexture(this.ghostRailTex);
    gl.deleteTexture(this.terrainTex);
    // Don't delete tileTex, paletteTex, or effectTex — shared with other passes
  }
}
