import { Logger } from "winston";
import WebSocket from "ws";
import {
  Difficulty,
  GameMapSize,
  GameMapType,
  GameMode,
  GameType,
} from "../core/game/Game";
import { GameConfig, GameID, PublicGameType } from "../core/Schemas";
import { Client } from "./Client";
import { GamePhase, GameServer, JoinResult } from "./GameServer";
import {
  noopMatchTelemetryEmitter,
  type MatchTelemetryEmitter,
} from "./telemetry/MatchTelemetry";

export class GameManager {
  private games: Map<GameID, GameServer> = new Map();

  constructor(
    private log: Logger,
    private readonly telemetry: MatchTelemetryEmitter = noopMatchTelemetryEmitter,
    private readonly telemetryBuildHash: string = "DEV",
  ) {
    setInterval(() => this.tick(), 1000);
  }

  public game(id: GameID): GameServer | null {
    return this.games.get(id) ?? null;
  }

  public publicLobbies(): GameServer[] {
    return Array.from(this.games.values()).filter(
      (g) => g.phase() === GamePhase.Lobby && g.isPublic(),
    );
  }

  // Private lobbies a subscriber has listed in the public lobby browser.
  // Leaving the Lobby phase (start/fill/expiry) delists them automatically.
  public listedLobbies(): GameServer[] {
    return Array.from(this.games.values()).filter(
      (g) => g.phase() === GamePhase.Lobby && !g.isPublic() && g.isListed(),
    );
  }

  joinClient(client: Client, gameID: GameID): JoinResult | "not_found" {
    const game = this.games.get(gameID);
    if (!game) return "not_found";
    return game.joinClient(client);
  }

  rejoinClient(
    ws: WebSocket,
    persistentID: string,
    gameID: GameID,
    lastTurn: number = 0,
    identityUpdate?: { username: string; clanTag: string | null },
  ): boolean {
    const game = this.games.get(gameID);
    if (!game) return false;
    return game.rejoinClient(ws, persistentID, lastTurn, identityUpdate);
  }

  createGame(
    id: GameID,
    gameConfig: Partial<GameConfig> | undefined,
    creatorPersistentID?: string,
    startsAt?: number,
    publicGameType?: PublicGameType,
    matchmakingTeams?: string[][],
  ): GameServer | null {
    if (this.games.has(id)) {
      this.log.warn("cannot create game, id already exists", { gameID: id });
      return null;
    }

    const game = new GameServer(
      {
        id,
        log: this.log,
        createdAt: Date.now(),
        gameConfig: {
          donateGold: false,
          donateTroops: false,
          gameMap: GameMapType.World,
          gameType: GameType.Private,
          gameMapSize: GameMapSize.Normal,
          difficulty: Difficulty.Easy,
          nations: "default",
          infiniteGold: false,
          infiniteTroops: false,
          maxTimerValue: undefined,
          instantBuild: false,
          randomSpawn: false,
          gameMode: GameMode.FFA,
          bots: 400,
          disabledUnits: [],
          ...gameConfig,
        },
        creatorPersistentID,
        startsAt,
        publicGameType,
        matchmakingTeams,
      },
      {
        telemetry: this.telemetry,
        telemetryBuildHash: this.telemetryBuildHash,
      },
    );
    this.games.set(id, game);
    return game;
  }

  activeGames(): number {
    return this.games.size;
  }

  activeClients(): number {
    let totalClients = 0;
    this.games.forEach((game: GameServer) => {
      totalClients += game.numClients();
    });
    return totalClients;
  }

  desyncCount(): number {
    return [...this.games.values()].reduce(
      (acc, game) => acc + game.numDesyncedClients(),
      0,
    );
  }

  tick() {
    const active = new Map<GameID, GameServer>();
    for (const [id, game] of this.games) {
      game.pruneStaleClients();
      const phase = game.phase();
      if (phase === GamePhase.Lobby) {
        game.maybeAutoStartListed();
      }
      if (phase === GamePhase.Active) {
        // A matchmade game missing a player at the start deadline is
        // cancelled instead of started short-handed.
        if (!game.hasStarted() && !game.cancelShortHandedMatch()) {
          // Never start a game nobody is connected to. A lobby that filled up
          // and then emptied reports Active (reaching maxPlayers takes it out
          // of the Lobby phase), and the reap in phase() holds off until the
          // ping clock goes quiet — so without this it would prestart and
          // start with an empty roster, emitting a playerless match_started
          // and running turns for nobody until the reaper caught up.
          if (game.numClients() === 0) {
            this.log.info("not starting game, no clients connected", {
              gameID: id,
            });
          } else {
            // Prestart tells clients to start loading the game.
            game.prestart();
            // Start game on delay to allow time for clients to connect.
            setTimeout(() => {
              try {
                // The roster can empty inside the delay, and start() does not
                // check: it would emit a playerless match_started and run
                // turns for nobody. Held rather than cancelled, because a
                // socket that just closed is often reconnecting.
                if (game.numClients() === 0) {
                  game.deferStart();
                  return;
                }
                game.start();
              } catch (error) {
                this.log.error(`error starting game ${id}: ${error}`);
              }
            }, 2000);
          }
        } else {
          // A start held because the roster was momentarily empty runs as
          // soon as anyone is back. No-op for every other running game.
          game.resumeDeferredStart();
        }
      }

      if (phase === GamePhase.Finished) {
        try {
          game.end();
        } catch (error) {
          this.log.error(`error ending game ${id}: ${error}`);
        }
      } else {
        active.set(id, game);
      }
    }
    this.games = active;
  }
}
