import { z } from "zod";
import { zb, ZbEncodeError } from "../../zbin";
import { UnitType } from "./game/Game";

export const bombUnits = ["abomb", "hbomb", "mirv", "mirvw"] as const;
export const BombUnitSchema = z.enum(bombUnits);
export type BombUnit = z.infer<typeof BombUnitSchema>;
export type NukeType =
  | UnitType.AtomBomb
  | UnitType.HydrogenBomb
  | UnitType.MIRV
  | UnitType.MIRVWarhead;

export const unitTypeToBombUnit = {
  [UnitType.AtomBomb]: "abomb",
  [UnitType.HydrogenBomb]: "hbomb",
  [UnitType.MIRV]: "mirv",
  [UnitType.MIRVWarhead]: "mirvw",
} as const satisfies Record<NukeType, BombUnit>;

export const boatUnits = ["trade", "trans"] as const;
export const BoatUnitSchema = z.enum(boatUnits);
export type BoatUnit = z.infer<typeof BoatUnitSchema>;
export type BoatUnitType = UnitType.TradeShip | UnitType.TransportShip;

// export const unitTypeToBoatUnit = {
//   [UnitType.TradeShip]: "trade",
//   [UnitType.TransportShip]: "trans",
// } as const satisfies Record<BoatUnitType, BoatUnit>;

export const otherUnits = [
  "city",
  "defp",
  "port",
  "wshp",
  "silo",
  "saml",
  "fact",
] as const;
export const OtherUnitSchema = z.enum(otherUnits);
export type OtherUnit = z.infer<typeof OtherUnitSchema>;
export type OtherUnitType =
  | UnitType.City
  | UnitType.DefensePost
  | UnitType.MissileSilo
  | UnitType.Port
  | UnitType.SAMLauncher
  | UnitType.Warship
  | UnitType.Factory;

export const unitTypeToOtherUnit = {
  [UnitType.City]: "city",
  [UnitType.DefensePost]: "defp",
  [UnitType.MissileSilo]: "silo",
  [UnitType.Port]: "port",
  [UnitType.SAMLauncher]: "saml",
  [UnitType.Warship]: "wshp",
  [UnitType.Factory]: "fact",
} as const satisfies Record<OtherUnitType, OtherUnit>;

// Attacks
export const ATTACK_INDEX_SENT = 0; // Outgoing attack troops
export const ATTACK_INDEX_RECV = 1; // Incmoing attack troops
export const ATTACK_INDEX_CANCEL = 2; // Cancelled attack troops

// Player types
export const PLAYER_INDEX_HUMAN = 0;
export const PLAYER_INDEX_NATION = 1;
export const PLAYER_INDEX_BOT = 2;

// Boats
export const BOAT_INDEX_SENT = 0; // Boats launched
export const BOAT_INDEX_ARRIVE = 1; // Boats arrived
export const BOAT_INDEX_CAPTURE = 2; // Boats captured
export const BOAT_INDEX_DESTROY = 3; // Boats destroyed

// Bombs
export const BOMB_INDEX_LAUNCH = 0; // Bombs launched
export const BOMB_INDEX_LAND = 1; // Bombs landed
export const BOMB_INDEX_INTERCEPT = 2; // Bombs intercepted

// Gold
export const GOLD_INDEX_WORK = 0; // Gold earned by workers
export const GOLD_INDEX_WAR = 1; // Gold earned by conquering players
export const GOLD_INDEX_TRADE = 2; // Gold earned by trade ships
export const GOLD_INDEX_STEAL = 3; // Gold earned by capturing trade ships
export const GOLD_INDEX_TRAIN_SELF = 4; // Gold earned by own trains
export const GOLD_INDEX_TRAIN_OTHER = 5; // Gold earned by other players trains

// Other Units
export const OTHER_INDEX_BUILT = 0; // Structures and warships built
export const OTHER_INDEX_DESTROY = 1; // Structures and warships destroyed
export const OTHER_INDEX_CAPTURE = 2; // Structures captured
export const OTHER_INDEX_LOST = 3; // Structures/warships destroyed/captured by others
export const OTHER_INDEX_UPGRADE = 4; // Structures upgraded

// Stats are bigints in the engine but ride HTTP/JSON as decimal strings (see
// `replacer`), so the schema accepts either. On the binary wire they encode as
// a bigint varint; the codec applies the same coercion as the preprocess so
// both in-memory shapes serialize identically.
export const BigIntStringSchema = zb.custom(
  z.preprocess((val) => {
    if (val === null) return 0n;
    if (typeof val === "string" && /^-?\d+$/.test(val)) return BigInt(val);
    if (typeof val === "bigint") return val;
    return val;
  }, z.bigint()),
  {
    enc: (w, v) => w.bigint(toBigInt(v)),
    dec: (r) => r.bigint(),
    minBytes: 1,
  },
);

function toBigInt(v: unknown): bigint {
  if (typeof v === "bigint") return v;
  if (v === null || v === undefined) return 0n;
  if (typeof v === "string" && /^-?\d+$/.test(v)) return BigInt(v);
  throw new ZbEncodeError(`not a bigint-valued stat: ${String(v)}`);
}

const AtLeastOneNumberSchema = BigIntStringSchema.array().min(1);
export type AtLeastOneNumber = z.infer<typeof AtLeastOneNumberSchema>;

export const PlayerStatsSchema = z
  .object({
    attacks: AtLeastOneNumberSchema.optional(),
    betrayals: BigIntStringSchema.optional(),
    killedAt: BigIntStringSchema.optional(),
    // OFM live standings: the eliminator's clientID (null = eliminated by a
    // non-client, e.g. a bot/nation) and finishing place at elimination. Both
    // first-write-wins. Surfaced live on the PlayerUpdate (not just at game end).
    killedBy: z.string().nullable().optional(),
    deathPosition: zb.uint().optional(),
    // Tiles owned at game end, for OFM standings (set on setWinner).
    finalTiles: BigIntStringSchema.optional(),
    // Humans this player eliminated (victim clientID + tick), for OFM kill scoring.
    kills: z
      .array(z.object({ victim: z.string(), tick: BigIntStringSchema }))
      .optional(),
    conquests: AtLeastOneNumberSchema.optional(),
    boats: z.partialRecord(BoatUnitSchema, AtLeastOneNumberSchema).optional(),
    bombs: z.partialRecord(BombUnitSchema, AtLeastOneNumberSchema).optional(),
    gold: AtLeastOneNumberSchema.optional(),
    units: z.partialRecord(OtherUnitSchema, AtLeastOneNumberSchema).optional(),
  })
  .optional();
export type PlayerStats = z.infer<typeof PlayerStatsSchema>;

// Reading archived records: `conquests` was a single value
// (BigIntStringSchema) before it was split into per-player-type buckets, so
// wrap old scalars into a one-element array (index 0 = human) on read.
export const ArchivedPlayerStatsSchema = z.preprocess((val) => {
  if (
    val !== null &&
    typeof val === "object" &&
    !Array.isArray(val) &&
    "conquests" in val
  ) {
    const { conquests } = val as { conquests: unknown };
    if (conquests !== undefined && !Array.isArray(conquests)) {
      return { ...(val as Record<string, unknown>), conquests: [conquests] };
    }
  }
  return val;
}, PlayerStatsSchema);
